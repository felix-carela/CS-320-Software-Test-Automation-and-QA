package com.taskmanager;

public class Task {
    private final String id; // Unique identifier, immutable
    private String name;     // Task name
    private String description; // Task description

    // Constructor
    public Task(String id, String name, String description) {
        if(id == null || id.length() > 10) {
            throw new IllegalArgumentException("Task ID cannot be null and must be less than or equal to 10 characters.");
        }
        if(name == null || name.length() > 20) {
            throw new IllegalArgumentException("Task name cannot be null and must be less than or equal to 20 characters.");
        }
        if(description == null || description.length() > 50) {
            throw new IllegalArgumentException("Task description cannot be null and must be less than or equal to 50 characters.");
        }

        this.id = id;
        this.name = name;
        this.description = description;
    }

    // Getters
    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getDescription() {
        return description;
    }

    // Setters
    public void setName(String name) {
        if(name == null || name.length() > 20) {
            throw new IllegalArgumentException("Task name cannot be null and must be less than or equal to 20 characters.");
        }
        this.name = name;
    }

    public void setDescription(String description) {
        if(description == null || description.length() > 50) {
            throw new IllegalArgumentException("Task description cannot be null and must be less than or equal to 50 characters.");
        }
        this.description = description;
    }
}
