package com.taskmanager;

import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;

public class TaskServiceTest {
    private TaskService taskService;

    @Before
    public void setUp() {
        taskService = new TaskService();
    }
    
    // Test adding multiple tasks with unique IDs
    @Test
    public void testAddMultipleTasksWithUniqueIds() {
        taskService.addTask("1", "First Task", "Description of the first task");
        taskService.addTask("2", "Second Task", "Description of the second task");
        taskService.addTask("3", "Third Task", "Description of the third task");

        assertNotNull("Task with ID '1' should be added", taskService.getTask("1"));
        assertNotNull("Task with ID '2' should be added", taskService.getTask("2"));
        assertNotNull("Task with ID '3' should be added", taskService.getTask("3"));
        assertNotEquals("Tasks should have unique IDs", taskService.getTask("1"), taskService.getTask("2"));
        assertNotEquals("Tasks should have unique IDs", taskService.getTask("1"), taskService.getTask("3"));
    }

    @Test
    public void testAddTask() {
        taskService.addTask("1", "Test Task", "This is a test task");
        assertNotNull(taskService.getTask("1"));
    }

    @Test(expected = IllegalArgumentException.class)
    public void testAddTaskWithDuplicateId() {
        taskService.addTask("1", "Test Task", "This is a test task");
        taskService.addTask("1", "Another Task", "This task should not be added");
    }

    @Test
    public void testDeleteTask() {
        taskService.addTask("1", "Test Task", "This is a test task");
        taskService.deleteTask("1");
        assertNull(taskService.getTask("1"));
    }

    @Test(expected = IllegalArgumentException.class)
    public void testDeleteNonexistentTask() {
        taskService.deleteTask("99");
    }

    @Test
    public void testUpdateTaskName() {
        taskService.addTask("1", "Test Task", "This is a test task");
        taskService.updateTaskName("1", "Updated Task");
        assertEquals("Updated Task", taskService.getTask("1").getName());
    }

    @Test(expected = IllegalArgumentException.class)
    public void testUpdateNonexistentTaskName() {
        taskService.updateTaskName("99", "Updated Task");
    }

    @Test
    public void testUpdateTaskDescription() {
        taskService.addTask("1", "Test Task", "This is a test task");
        taskService.updateTaskDescription("1", "Updated Description");
        assertEquals("Updated Description", taskService.getTask("1").getDescription());
    }

    @Test(expected = IllegalArgumentException.class)
    public void testUpdateNonexistentTaskDescription() {
        taskService.updateTaskDescription("99", "Updated Description");
    }
}
