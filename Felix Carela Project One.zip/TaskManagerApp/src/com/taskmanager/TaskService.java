package com.taskmanager;

import java.util.HashMap;
import java.util.Map;

public class TaskService {
    private Map<String, Task> tasks;

    public TaskService() {
        tasks = new HashMap<>();
    }

    public void addTask(String id, String name, String description) {
        if (tasks.containsKey(id)) {
            throw new IllegalArgumentException("A task with this ID already exists.");
        }
        tasks.put(id, new Task(id, name, description));
    }

    public void deleteTask(String id) {
        if (!tasks.containsKey(id)) {
            throw new IllegalArgumentException("No task found with this ID.");
        }
        tasks.remove(id);
    }

    public void updateTaskName(String id, String newName) {
        if (!tasks.containsKey(id)) {
            throw new IllegalArgumentException("No task found with this ID.");
        }
        tasks.get(id).setName(newName);
    }

    public void updateTaskDescription(String id, String newDescription) {
        if (!tasks.containsKey(id)) {
            throw new IllegalArgumentException("No task found with this ID.");
        }
        tasks.get(id).setDescription(newDescription);
    }

    public Task getTask(String id) {
        return tasks.get(id);
    }
}
