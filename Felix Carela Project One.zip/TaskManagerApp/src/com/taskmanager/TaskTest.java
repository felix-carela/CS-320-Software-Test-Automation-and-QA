package com.taskmanager;

import org.junit.Test;
import static org.junit.Assert.*;

public class TaskTest {

    @Test
    public void testTaskCreation() {
        Task task = new Task("1", "Test Task", "This is a test task");
        assertNotNull(task);
        assertEquals("1", task.getId());
        assertEquals("Test Task", task.getName());
        assertEquals("This is a test task", task.getDescription());
    }
    
    // Test id
    @Test(expected = IllegalArgumentException.class)
    public void testTaskWithLongId() {
        new Task("12345678901", "Test Task", "This is a test task");
    }

    @Test(expected = IllegalArgumentException.class)
    public void testTaskWithNullId() {
        new Task(null, "Test Task", "This is a test task");
    }
    
    @Test
    public void testValidTaskIdMaxLength() {
        Task task = new Task("1234567890", "Test Task", "Description");
        assertEquals("Expected task ID to be '1234567890'", "1234567890", task.getId());
    }

    @Test
    public void testValidTaskIdMinLength() {
        Task task = new Task("1", "Test Task", "Description");
        assertEquals("Expected task ID to be '1'", "1", task.getId());
    }
    
    // Test name
    @Test(expected = IllegalArgumentException.class)
    public void testTaskWithLongName() {
        new Task("1", "This name is definitely more than twenty characters", "This is a test task");
    }

    @Test(expected = IllegalArgumentException.class)
    public void testTaskWithNullName() {
        new Task("1", null, "This is a test task");
    }
    
    public void testValidTaskNameMaxLength() {
        Task task = new Task("1", "12345678901234567890", "Description");
        assertEquals("Expected task name to have 20 characters", "12345678901234567890", task.getName());
    }

    @Test
    public void testValidTaskNameUnderMaxLength() {
        Task task = new Task("1", "Short Name", "Description");
        assertEquals("Expected task name to be 'Short Name'", "Short Name", task.getName());
    }
    
    // Test description
    @Test(expected = IllegalArgumentException.class)
    public void testTaskWithLongDescription() {
        new Task("1", "Test Task", "This description is definitely more than fifty characters. It goes on and on and just doesn't stop.");
    }

    @Test(expected = IllegalArgumentException.class)
    public void testTaskWithNullDescription() {
        new Task("1", "Test Task", null);
    }
    
    @Test
    public void testValidTaskDescriptionMaxLength() {
        Task task = new Task("1", "Test Task", "12345678901234567890123456789012345678901234567890");
        assertEquals("Expected task description to have 50 characters", "12345678901234567890123456789012345678901234567890", task.getDescription());
    }

    @Test
    public void testValidTaskDescriptionUnderMaxLength() {
        Task task = new Task("1", "Test Task", "Short Description");
        assertEquals("Expected task description to be 'Short Description'", "Short Description", task.getDescription());
    }

    @Test
    public void testUpdateName() {
        Task task = new Task("1", "Test Task", "This is a test task");
        task.setName("Updated Name");
        assertEquals("Updated Name", task.getName());
    }

    @Test(expected = IllegalArgumentException.class)
    public void testUpdateWithLongName() {
        Task task = new Task("1", "Test Task", "This is a test task");
        task.setName("This name is definitely more than twenty characters");
    }

    @Test
    public void testUpdateDescription() {
        Task task = new Task("1", "Test Task", "This is a test task");
        task.setDescription("Updated Description");
        assertEquals("Updated Description", task.getDescription());
    }

    @Test(expected = IllegalArgumentException.class)
    public void testUpdateWithLongDescription() {
        Task task = new Task("1", "Test Task", "This is a test task");
        task.setDescription("This description is definitely more than fifty characters. It goes on and on and just doesn't stop.");
    }
}
