package com.appointmentservice;

import org.junit.Before;
import org.junit.Test;
import java.util.Date;
import static org.junit.Assert.*;

public class AppointmentServiceTest {

    private AppointmentService service;
    private Appointment appointment1;

    @Before
    public void setUp() {
        service = new AppointmentService();
        appointment1 = new Appointment("A123", new Date(), "Description 1");
    }

    @Test
    public void addAppointment_ShouldAddAppointment_WhenGivenValidAppointment() {
        service.addAppointment(appointment1);
        assertNotNull(service.getAppointment(appointment1.getAppointmentId()));
    }

    @Test(expected = IllegalArgumentException.class)
    public void addAppointment_ShouldThrowException_WhenAddingDuplicateId() {
        service.addAppointment(appointment1);
        service.addAppointment(appointment1);
    }

    @Test(expected = IllegalArgumentException.class)
    public void addAppointment_ShouldThrowException_WhenAddingNullAppointment() {
        service.addAppointment(null);
    }
    
    @Test
    public void deleteAppointment_ShouldDeleteAppointment_WhenGivenValidId() {
        service.addAppointment(appointment1);
        service.deleteAppointment(appointment1.getAppointmentId());
        assertNull(service.getAppointment(appointment1.getAppointmentId()));
    }

    @Test(expected = IllegalArgumentException.class)
    public void deleteAppointment_ShouldThrowException_WhenGivenInvalidId() {
        service.deleteAppointment("InvalidId");
    }

    @Test(expected = IllegalArgumentException.class)
    public void deleteAppointment_ShouldThrowException_WhenGivenNullId() {
        service.deleteAppointment(null);
    }
    
    @Test
    public void getAppointment_ShouldReturnCorrectAppointment_WhenCalledMultipleTimes() {
        Date futureDate = new Date(System.currentTimeMillis() + 24 * 60 * 60 * 1000);
        Appointment appointment = new Appointment("A12346", futureDate, "Consistent Retrieval Test");
        service.addAppointment(appointment);
        assertEquals(service.getAppointment("A12346"), appointment);
        assertEquals(service.getAppointment("A12346"), appointment);
    }

    @Test
    public void updateAppointmentDescription_MultipleTimes_ShouldReflectChanges() {
        Date futureDate = new Date(System.currentTimeMillis() + 24 * 60 * 60 * 1000);
        Appointment appointment = new Appointment("A12347", futureDate, "Initial Description");
        service.addAppointment(appointment);
        appointment.setDescription("Updated Once");
        assertEquals("Updated Once", service.getAppointment("A12347").getDescription());
        appointment.setDescription("Updated Twice");
        assertEquals("Updated Twice", service.getAppointment("A12347").getDescription());
    }
    
    @Test(expected = IllegalArgumentException.class)
    public void deleteAppointment_Twice_ShouldThrowException() {
        service.addAppointment(appointment1);
        service.deleteAppointment(appointment1.getAppointmentId());
        service.deleteAppointment(appointment1.getAppointmentId());
    }

}
