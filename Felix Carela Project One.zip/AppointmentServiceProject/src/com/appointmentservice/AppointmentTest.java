package com.appointmentservice;

import org.junit.Test;
import java.util.Date;
import static org.junit.Assert.*;

public class AppointmentTest {

    @Test
    public void createAppointment_ValidDetails_ShouldCreateSuccessfully() {
        Date futureDate = new Date(System.currentTimeMillis() + 24 * 60 * 60 * 1000);
        Appointment appointment = new Appointment("A12345", futureDate, "Checkup");

        assertEquals("A12345", appointment.getAppointmentId());
        assertEquals(futureDate, appointment.getAppointmentDate());
        assertEquals("Checkup", appointment.getDescription());
    }
    
    // Test id
    @Test(expected = IllegalArgumentException.class)
    public void createAppointment_InvalidId_ShouldThrowException() {
        new Appointment("12345678901", new Date(), "Checkup");
    }

    @Test(expected = IllegalArgumentException.class)
    public void createAppointment_NullId_ShouldThrowException() {
        new Appointment(null, new Date(), "Checkup");
    }
    
    @Test
    public void appointmentId_MaxLength_ShouldCreateSuccessfully() {
        Date futureDate = new Date(System.currentTimeMillis() + 24 * 60 * 60 * 1000);
        Appointment appointment = new Appointment("1234567890", futureDate, "Regular check");
        assertEquals("1234567890", appointment.getAppointmentId());
    }

    @Test
    public void appointmentId_LessThanMax_ShouldCreateSuccessfully() {
        Date futureDate = new Date(System.currentTimeMillis() + 24 * 60 * 60 * 1000);
        Appointment appointment = new Appointment("12345", futureDate, "Regular check");
        assertEquals("12345", appointment.getAppointmentId());
    }
    
    @Test(expected = IllegalArgumentException.class)
    public void createAppointment_PastDate_ShouldThrowException() {
        new Appointment("A12345", new Date(System.currentTimeMillis() - 24 * 60 * 60 * 1000), "Checkup");
    }

    @Test(expected = IllegalArgumentException.class)
    public void createAppointment_NullDate_ShouldThrowException() {
        new Appointment("A12345", null, "Checkup");
    }
    
    @Test
    public void setAppointmentDate_FutureDate_ShouldUpdateSuccessfully() {
    	Date futureDate = new Date(System.currentTimeMillis() + 24 * 60 * 60 * 1000);
    	Appointment appointment = new Appointment("A12345", new Date(), "Checkup");
    	appointment.setAppointmentDate(futureDate);
    	
    	assertEquals(futureDate, appointment.getAppointmentDate());
    }
    
    @Test(expected = IllegalArgumentException.class)
    public void setAppointmentDate_PastDate_ShouldThrowException() {
    	Appointment appointment = new Appointment("A12345", new Date(), "Checkup");
    	appointment.setAppointmentDate(new Date(System.currentTimeMillis() - 24 * 60 * 60 * 1000));
    }
    
    // Test description
    @Test(expected = IllegalArgumentException.class)
    public void createAppointment_InvalidDescription_ShouldThrowException() {
        new Appointment("A12345", new Date(), String.format("%0" + 51 + "d", 0).replace("0", "a"));
    }

    @Test(expected = IllegalArgumentException.class)
    public void createAppointment_NullDescription_ShouldThrowException() {
        new Appointment("A12345", new Date(), null);
    }
    
    @Test
    public void description_MaxLength_ShouldCreateSuccessfully() {
        Date futureDate = new Date(System.currentTimeMillis() + 24 * 60 * 60 * 1000);
        String maxDescription = "12345678901234567890123456789012345678901234567890";
        Appointment appointment = new Appointment("A12345", futureDate, maxDescription);
        assertEquals(maxDescription, appointment.getDescription());
    }

    @Test
    public void description_LessThanMax_ShouldCreateSuccessfully() {
        Date futureDate = new Date(System.currentTimeMillis() + 24 * 60 * 60 * 1000);
        String shortDescription = "Short Description";
        Appointment appointment = new Appointment("A12345", futureDate, shortDescription);
        assertEquals(shortDescription, appointment.getDescription());
    }
    
    @Test
    public void setDescription_MaxLength_ShouldUpdateSuccessfully() {
        Date futureDate = new Date(System.currentTimeMillis() + 24 * 60 * 60 * 1000);
        Appointment appointment = new Appointment("A12345", futureDate, "Initial Description");
        String maxLengthDescription = "12345678901234567890123456789012345678901234567890"; // Exactly 50 characters
        appointment.setDescription(maxLengthDescription);
        assertEquals(maxLengthDescription, appointment.getDescription());
    }

    @Test(expected = IllegalArgumentException.class)
    public void setDescription_TooLong_ShouldThrowException() {
        Date futureDate = new Date(System.currentTimeMillis() + 24 * 60 * 60 * 1000);
        Appointment appointment = new Appointment("A12345", futureDate, "Initial Description");
        String tooLongDescription = "123456789012345678901234567890123456789012345678901"; // 51 characters
        appointment.setDescription(tooLongDescription);
    }

}
